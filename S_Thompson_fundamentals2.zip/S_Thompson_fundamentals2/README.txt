NAME: Shaun Thompson
TERM: 1501

https://github.com/n38803/MDF3

** I attempted utilizing the Signed APK both in this class and prior but have always had issues as it setups a keystore / jks file.  I've requested assistance from Mr. Story in the past but never received responses.  Can I schedule an appointment during your office hours so that I can correct this moving forward?

Notes:
 - Fragments implemented but do not correctly handle activity cycle with orientation change
 - Fixed notification to run in foreground
 - Fixed issue with "Stop" resetting to a pause state
 - Fixed issue where song was looping all the time
 - Device works in both orientations (when launching from that orientation).. additionally, it continues to work when there is an orientation change.. as I have removed my code to change fragments because it kept breaking.



