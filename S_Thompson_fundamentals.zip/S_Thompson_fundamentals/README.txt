NAME: Shaun Thompson
TERM: 1501

https://github.com/n38803/MDF3

** Please note that I have included 2 APK files.  I did not do this in ignorance of the deliverables for the assignment, but rather my confusion on which APK file actually generates the application.

There are always 2 in app>build>outputs>apk.

If you are able to inform me as to which one I am required to utilize, I can ensure that I do not upload two moving forward.


